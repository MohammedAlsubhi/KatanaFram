<html>
  <head>
    <title>I am watching you.</title>
  </head>
  <body BGCOLOR="BLACK" TEXT="RED">
    <table WIDTH="100%" HEIGHT="100%"><tr>
      <td VALIGN="MIDDLE" ALIGN="CENTER">
       <h1><b>I am watching you.</b></h1>
      </td></tr>
    </table>  
  </body>
</html>
