#!/usr/bin/env python2
#HEAD#########################################################
#
# Katana Framework | APIs Instance
# Last Modified: 24/12/2016
#
#########################################################HEAD#

from core.Function import *
printk    = printk()
NET       = NET()
UTIL      = UTIL()
GRAPHICAL = GRAPHICAL()
COM       = COM()
SYSTEM    = SYSTEM()
WEB       = WEB()