.. upgrading

Upgrading
*********

We strive to support compatibility between versions of ``python-future``. Part of this involves keeping around old interfaces and marking them as deprecated for a period to allow projects to transition in a straightforward manner to using the new interfaces.


.. upgrading-to-v0.12

Upgrading to v0.12
==================

